import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

public class TransactionDAO {

    public void recordTransaction(int accountId, String type, BigDecimal amount, BigDecimal newBalance, String remarks) throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO transactions (account_id, tx_type, amount, balance_after, remarks) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, accountId);
            pst.setString(2, type);
            pst.setBigDecimal(3, amount);
            pst.setBigDecimal(4, newBalance);
            pst.setString(5, remarks);
            pst.executeUpdate();
        }
    }

    public List<Transaction> findRecentTransactions(int accountId, int limit) throws Exception {
        List<Transaction> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM transactions WHERE account_id = ? ORDER BY tx_time DESC LIMIT ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, accountId);
            pst.setInt(2, limit);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Transaction t = new Transaction();
                t.setTxId(rs.getInt("tx_id"));
                t.setAccountId(rs.getInt("account_id"));
                t.setTxType(rs.getString("tx_type"));
                t.setAmount(rs.getBigDecimal("amount"));
                t.setBalanceAfter(rs.getBigDecimal("balance_after"));
                t.setTxTime(rs.getTimestamp("tx_time"));
                t.setRemarks(rs.getString("remarks"));
                list.add(t);
            }
        }
        return list;
    }
}
