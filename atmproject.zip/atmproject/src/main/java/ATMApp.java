import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.math.BigDecimal;
import java.util.Optional;

public class ATMApp {
    private JFrame frame;
    private ATMService atmService = new ATMService();
    private Account loggedIn;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ATMApp().createAndShowGUI());
    }

    private void createAndShowGUI() {
        frame = new JFrame("?ATM Banking System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 450); // Bigger, cleaner window
        frame.setLocationRelativeTo(null);
        frame.getContentPane().setBackground(new Color(245, 245, 250));
        showLogin();
        frame.setVisible(true);
    }

    // ---------------- LOGIN PAGE ----------------
    private void showLogin() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBackground(new Color(245, 245, 250));

        JLabel title = new JLabel("?Welcome to Smart ATM", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 24));
        title.setForeground(new Color(25, 25, 112));

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel accLabel = new JLabel("Account Number:");
        accLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        JTextField accField = new JTextField(15);
        accField.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        JLabel pinLabel = new JLabel("PIN:");
        pinLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        JPasswordField pinField = new JPasswordField(15);
        pinField.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        JButton loginBtn = new JButton("Login");
        JButton cancelBtn = new JButton("Cancel");

        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        loginBtn.setBackground(new Color(0, 120, 215));
        loginBtn.setForeground(Color.WHITE);
        loginBtn.setFocusPainted(false);

        cancelBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        cancelBtn.setBackground(new Color(220, 53, 69));
        cancelBtn.setForeground(Color.WHITE);
        cancelBtn.setFocusPainted(false);

        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(accLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 0; formPanel.add(accField, gbc);
        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(pinLabel, gbc);
        gbc.gridx = 1; gbc.gridy = 1; formPanel.add(pinField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; formPanel.add(loginBtn, gbc);
        gbc.gridx = 1; gbc.gridy = 2; formPanel.add(cancelBtn, gbc);

        mainPanel.add(title, BorderLayout.NORTH);
        mainPanel.add(formPanel, BorderLayout.CENTER);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(mainPanel);
        frame.revalidate();
        frame.repaint();

        // ✅ Button Actions
        loginBtn.addActionListener((ActionEvent e) -> {
            String acc = accField.getText().trim();
            char[] pin = pinField.getPassword();
            try {
                Optional<Account> opt = atmService.authenticate(acc, pin);
                if (opt.isPresent()) {
                    loggedIn = opt.get();
                    JOptionPane.showMessageDialog(frame, "Welcome, " + loggedIn.getOwnerName(),
                            "Login Successful", JOptionPane.INFORMATION_MESSAGE);
                    showDashboard();
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid Account or PIN!", "Login Failed", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                java.util.Arrays.fill(pin, '0');
            }
        });

        cancelBtn.addActionListener(e -> {
            accField.setText("");
            pinField.setText("");
        });
    }

    // ---------------- DASHBOARD PAGE ----------------
    private void showDashboard() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(245, 245, 250));

        JLabel header = new JLabel("Welcome, " + loggedIn.getOwnerName(), SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.setForeground(new Color(25, 25, 112));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));

        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 15, 15));
        buttonPanel.setBackground(new Color(245, 245, 250));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 60, 40, 60));

        JButton balBtn = styledButton("View Balance");
        JButton withdrawBtn = styledButton("Withdraw");
        JButton depositBtn = styledButton("Deposit");
        JButton miniBtn = styledButton("Mini Statement");
        JButton logoutBtn = styledButton("Logout");

        buttonPanel.add(balBtn);
        buttonPanel.add(depositBtn);
        buttonPanel.add(withdrawBtn);
        buttonPanel.add(miniBtn);
        buttonPanel.add(logoutBtn);

        panel.add(header, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.CENTER);

        frame.getContentPane().removeAll();
        frame.getContentPane().add(panel);
        frame.revalidate();
        frame.repaint();

        // ---------------- Button Listeners ----------------
        balBtn.addActionListener(e ->
                JOptionPane.showMessageDialog(frame, "Your Balance: ₹ " + loggedIn.getBalance(), "Balance Info", JOptionPane.INFORMATION_MESSAGE));

        withdrawBtn.addActionListener(e -> {
    String amtS = JOptionPane.showInputDialog(frame, "Enter amount to withdraw:");
    if (amtS == null) return; // 🔹 User pressed cancel — do nothing safely

    amtS = amtS.trim();
    if (amtS.isEmpty()) {
        JOptionPane.showMessageDialog(frame, "Amount cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        BigDecimal amt = new BigDecimal(amtS);
        boolean ok = atmService.withdraw(loggedIn.getAccountId(), amt);
        if (ok) {
            loggedIn = new AccountDAO().findByAccountNumber(loggedIn.getAccountNumber()).get();
            JOptionPane.showMessageDialog(frame, "Withdrawn successfully.\nNew Balance: ₹ " + loggedIn.getBalance());
        } else {
            JOptionPane.showMessageDialog(frame, "Withdraw failed (insufficient funds or error).", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(frame, "Invalid input or error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
});

depositBtn.addActionListener(e -> {
    String amtS = JOptionPane.showInputDialog(frame, "Enter amount to deposit:");
    if (amtS == null) return; // 🔹 User pressed cancel — do nothing safely

    amtS = amtS.trim();
    if (amtS.isEmpty()) {
        JOptionPane.showMessageDialog(frame, "Amount cannot be empty!", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try {
        BigDecimal amt = new BigDecimal(amtS);
        boolean ok = atmService.deposit(loggedIn.getAccountId(), amt);
        if (ok) {
            loggedIn = new AccountDAO().findByAccountNumber(loggedIn.getAccountNumber()).get();
            JOptionPane.showMessageDialog(frame, "Deposited successfully.\nNew Balance: ₹ " + loggedIn.getBalance());
        } else {
            JOptionPane.showMessageDialog(frame, "Deposit failed.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(frame, "Invalid input or error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
});


        miniBtn.addActionListener(e -> {
            try {
                java.util.List<Transaction> txs = new TransactionDAO().findRecentTransactions(loggedIn.getAccountId(), 10);
                StringBuilder sb = new StringBuilder("Recent Transactions:\n\n");
                for (Transaction t : txs) {
                    sb.append(String.format("%s | %s | ₹%s | Balance: ₹%s\n",
                            t.getTxTime(), t.getTxType(), t.getAmount(), t.getBalanceAfter()));
                }
                JOptionPane.showMessageDialog(frame, sb.length() == 0 ? "No transactions found." : sb.toString(), "Mini Statement", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        logoutBtn.addActionListener(e -> {
            loggedIn = null;
            showLogin();
        });
    }

    // ---------------- Styling Helper ----------------
    private JButton styledButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btn.setBackground(new Color(0, 120, 215));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}
