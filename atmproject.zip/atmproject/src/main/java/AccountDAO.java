import java.sql.*;
import java.util.Optional;

public class AccountDAO {

    public Optional<Account> findByAccountNumber(String accNumber) throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM accounts WHERE account_number = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, accNumber);

            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Account a = new Account();
                a.setAccountId(rs.getInt("account_id"));
                a.setAccountNumber(rs.getString("account_number"));
                a.setOwnerName(rs.getString("owner_name"));
                a.setBalance(rs.getBigDecimal("balance"));
                return Optional.of(a);
            } else {
                return Optional.empty();
            }
        }
    }

    public boolean updateBalance(int accountId, java.math.BigDecimal delta) throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            PreparedStatement pst1 = conn.prepareStatement("SELECT balance FROM accounts WHERE account_id = ?");
            pst1.setInt(1, accountId);
            ResultSet rs = pst1.executeQuery();

            if (!rs.next()) return false;
            java.math.BigDecimal bal = rs.getBigDecimal("balance");
            java.math.BigDecimal newBal = bal.add(delta);
            if (newBal.compareTo(java.math.BigDecimal.ZERO) < 0) return false;

            PreparedStatement pst2 = conn.prepareStatement("UPDATE accounts SET balance = ? WHERE account_id = ?");
            pst2.setBigDecimal(1, newBal);
            pst2.setInt(2, accountId);
            pst2.executeUpdate();

            conn.commit();
            return true;
        }
    }
    
    public java.math.BigDecimal getBalance(int accountId) throws Exception {
    try (Connection conn = DBConnection.getConnection()) {
        String sql = "SELECT balance FROM accounts WHERE account_id = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setInt(1, accountId);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) return rs.getBigDecimal("balance");
        else return java.math.BigDecimal.ZERO;
    }
}

}
