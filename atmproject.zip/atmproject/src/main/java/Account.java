import java.math.BigDecimal;

public class Account {
    private int accountId;
    private String accountNumber;
    private String ownerName;
    private byte[] pinHash;
    private byte[] salt;
    private BigDecimal balance;
    private boolean locked;
    private int failedAttempts;

    // getters and setters ...
    public int getAccountId(){ return accountId; }
    public void setAccountId(int id){ this.accountId = id; }
    public String getAccountNumber(){ return accountNumber; }
    public void setAccountNumber(String s){ this.accountNumber = s; }
    public String getOwnerName(){ return ownerName; }
    public void setOwnerName(String s){ this.ownerName = s; }
    public byte[] getPinHash(){ return pinHash; }
    public void setPinHash(byte[] b){ this.pinHash = b; }
    public byte[] getSalt(){ return salt; }
    public void setSalt(byte[] s){ this.salt = s; }
    public BigDecimal getBalance(){ return balance; }
    public void setBalance(BigDecimal b){ this.balance = b; }
    public boolean isLocked(){ return locked; }
    public void setLocked(boolean v){ this.locked = v; }
    public int getFailedAttempts(){ return failedAttempts; }
    public void setFailedAttempts(int f){ this.failedAttempts = f; }
}
