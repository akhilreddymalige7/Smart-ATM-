import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.SecureRandom;
import java.util.Arrays;

public class SecurityUtil {
    private static final SecureRandom RAND = new SecureRandom();
    private static final int ITERATIONS = 10000;
    private static final int KEY_LENGTH = 256;

    public static byte[] generateSalt(int len) {
        byte[] salt = new byte[len];
        RAND.nextBytes(salt);
        return salt;
    }

    public static byte[] hashPin(char[] pin, byte[] salt) throws Exception {
        PBEKeySpec spec = new PBEKeySpec(pin, salt, ITERATIONS, KEY_LENGTH);
        SecretKeyFactory skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] hash = skf.generateSecret(spec).getEncoded();
        spec.clearPassword();
        return hash;
    }

    public static boolean verifyPin(char[] pin, byte[] salt, byte[] expectedHash) throws Exception {
        byte[] hash = hashPin(pin, salt);
        return Arrays.equals(hash, expectedHash);
    }
}
