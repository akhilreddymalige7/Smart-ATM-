import java.sql.*;
import java.util.Optional;
import java.math.BigDecimal;

public class ATMService {

    public Optional<Account> authenticate(String accNumber, char[] pin) throws Exception {
        String pinStr = new String(pin);
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM accounts WHERE account_number = ? AND pin_hash = ?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, accNumber);
            pst.setString(2, pinStr);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Account a = new Account();
                a.setAccountId(rs.getInt("account_id"));
                a.setAccountNumber(rs.getString("account_number"));
                a.setOwnerName(rs.getString("owner_name"));
                a.setBalance(rs.getBigDecimal("balance"));
                return Optional.of(a);
            } else {
                return Optional.empty();
            }
        }
    }

    public boolean withdraw(int accountId, BigDecimal amt) throws Exception {
        AccountDAO dao = new AccountDAO();
        boolean ok = dao.updateBalance(accountId, amt.negate());
        if (ok) {
            BigDecimal newBal = dao.getBalance(accountId);
            new TransactionDAO().recordTransaction(accountId, "WITHDRAW", amt, newBal, "Cash withdrawn");
        }
        return ok;
    }

    public boolean deposit(int accountId, BigDecimal amt) throws Exception {
        AccountDAO dao = new AccountDAO();
        boolean ok = dao.updateBalance(accountId, amt);
        if (ok) {
            BigDecimal newBal = dao.getBalance(accountId);
            new TransactionDAO().recordTransaction(accountId, "DEPOSIT", amt, newBal, "Cash deposit");
        }
        return ok;
    }
    
    public boolean transfer(int fromAccount, String toAccount, BigDecimal amount) {
    String withdrawQuery = "UPDATE account SET balance = balance - ? WHERE account_number = ?";
    String depositQuery = "UPDATE account SET balance = balance + ? WHERE account_number = ?";

    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps1 = conn.prepareStatement(withdrawQuery);
         PreparedStatement ps2 = conn.prepareStatement(depositQuery)) {

        conn.setAutoCommit(false);

        ps1.setBigDecimal(1, amount);
        ps1.setInt(2, fromAccount);
        int rows1 = ps1.executeUpdate();

        ps2.setBigDecimal(1, amount);
        ps2.setString(2, toAccount);
        int rows2 = ps2.executeUpdate();

        if (rows1 > 0 && rows2 > 0) {
            conn.commit();
            return true;
        } else {
            conn.rollback();
            return false;
        }

    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}

}
