import java.math.BigDecimal;
import java.sql.Timestamp;

public class Transaction {
    private int txId;
    private int accountId;
    private String txType;
    private BigDecimal amount;
    private BigDecimal balanceAfter;
    private Timestamp txTime;
    private String remarks;

    public int getTxId() { return txId; }
    public void setTxId(int txId) { this.txId = txId; }

    public int getAccountId() { return accountId; }
    public void setAccountId(int accountId) { this.accountId = accountId; }

    public String getTxType() { return txType; }
    public void setTxType(String txType) { this.txType = txType; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public BigDecimal getBalanceAfter() { return balanceAfter; }
    public void setBalanceAfter(BigDecimal balanceAfter) { this.balanceAfter = balanceAfter; }

    public Timestamp getTxTime() { return txTime; }
    public void setTxTime(Timestamp txTime) { this.txTime = txTime; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
}
